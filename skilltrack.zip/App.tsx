import React, { useState, useEffect, useMemo } from 'react';
import { Course, CourseStatus } from './types';
import { getInitialData, uniqueCategories } from './utils';
import { Sidebar } from './components/Sidebar';
import { CourseCard } from './components/CourseCard';
import { CourseModal } from './components/CourseModal';
import { Dashboard } from './components/Dashboard';
import { Search, Filter, SortAsc } from 'lucide-react';

const App: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [currentView, setCurrentView] = useState<'dashboard' | 'courses'>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  
  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortConfig, setSortConfig] = useState<{ key: keyof Course | 'status'; direction: 'asc' | 'desc' }>({ key: 'date', direction: 'desc' });

  // Initialize Data
  useEffect(() => {
    const data = getInitialData();
    setCourses(data);
  }, []);

  // Save to LocalStorage on change
  useEffect(() => {
    if (courses.length > 0) {
      localStorage.setItem('skilltrack_courses', JSON.stringify(courses));
    }
  }, [courses]);

  const categories = useMemo(() => ['All', ...uniqueCategories(courses)], [courses]);

  const filteredCourses = useMemo(() => {
    let result = [...courses];

    // Filter by Category
    if (selectedCategory !== 'All') {
      result = result.filter(c => c.category === selectedCategory);
    }

    // Filter by Search
    if (searchQuery) {
      const lowerQ = searchQuery.toLowerCase();
      result = result.filter(c => 
        c.title.toLowerCase().includes(lowerQ) || 
        c.category.toLowerCase().includes(lowerQ)
      );
    }

    // Sort
    result.sort((a, b) => {
        let valA = a[sortConfig.key as keyof Course];
        let valB = b[sortConfig.key as keyof Course];

        if (sortConfig.key === 'date') {
            // Basic date parser for MM/DD/YYYY
            valA = new Date(a.date).getTime();
            valB = new Date(b.date).getTime();
        }

        if (valA === undefined) valA = '';
        if (valB === undefined) valB = '';

        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
    });

    // Pinned/Favorites always on top
    result.sort((a, b) => {
        if (a.isFavorite === b.isFavorite) return 0;
        return a.isFavorite ? -1 : 1;
    });

    return result;
  }, [courses, selectedCategory, searchQuery, sortConfig]);

  const handleAddCourse = () => {
    setEditingCourse(null);
    setIsModalOpen(true);
  };

  const handleEditCourse = (course: Course) => {
    setEditingCourse(course);
    setIsModalOpen(true);
  };

  const handleSaveCourse = (updatedCourse: Course) => {
    setCourses(prev => {
      const exists = prev.find(c => c.id === updatedCourse.id);
      if (exists) {
        return prev.map(c => c.id === updatedCourse.id ? updatedCourse : c);
      }
      return [updatedCourse, ...prev];
    });
  };

  const toggleFavorite = (id: string) => {
    setCourses(prev => prev.map(c => c.id === id ? { ...c, isFavorite: !c.isFavorite } : c));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex">
      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        onAddCourse={handleAddCourse}
      />
      
      <main className="flex-1 md:ml-64 p-6 overflow-hidden">
        {/* Top Header - Mobile compatible */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <h1 className="text-3xl font-bold tracking-tight">
                {currentView === 'dashboard' ? 'Overview' : 'My Library'}
            </h1>
            
            {/* Search and Filter Bar - Only visible in courses view or if needed globally */}
            <div className={`flex flex-col sm:flex-row gap-3 w-full md:w-auto ${currentView === 'dashboard' ? 'hidden md:flex' : ''}`}>
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input 
                        type="text" 
                        placeholder="Search courses..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 w-full sm:w-64 text-sm"
                    />
                </div>
                {currentView === 'courses' && (
                    <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="px-4 py-2 bg-slate-900 border border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm max-w-[200px]"
                    >
                        {categories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                )}
            </div>
        </div>

        <div className="max-w-7xl mx-auto pb-10">
            {currentView === 'dashboard' ? (
                <Dashboard courses={courses} />
            ) : (
                <>
                    {/* Library Controls */}
                    <div className="flex justify-between items-center mb-6 text-sm text-slate-400">
                        <span>Showing {filteredCourses.length} courses</span>
                        <div className="flex items-center gap-2">
                             <span className="hidden sm:inline">Sort by:</span>
                             <select 
                                onChange={(e) => setSortConfig({ key: e.target.value as any, direction: 'desc' })}
                                className="bg-transparent border-none text-indigo-400 font-medium focus:ring-0 cursor-pointer"
                             >
                                <option value="date">Date Added</option>
                                <option value="completionRatio">Progress</option>
                                <option value="title">Title</option>
                             </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {filteredCourses.map(course => (
                            <CourseCard 
                                key={course.id} 
                                course={course} 
                                onEdit={handleEditCourse}
                                onToggleFavorite={toggleFavorite}
                            />
                        ))}
                    </div>

                    {filteredCourses.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-20 text-slate-500">
                            <Filter size={48} className="mb-4 opacity-50" />
                            <p className="text-lg">No courses found matching your criteria.</p>
                        </div>
                    )}
                </>
            )}
        </div>
      </main>

      <CourseModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveCourse}
        initialData={editingCourse}
        categories={categories.filter(c => c !== 'All')}
      />
    </div>
  );
};

export default App;