import React from 'react';
import { LayoutDashboard, BookOpen, PlusCircle } from 'lucide-react';

interface SidebarProps {
  currentView: 'dashboard' | 'courses';
  setView: (view: 'dashboard' | 'courses') => void;
  onAddCourse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, onAddCourse }) => {
  return (
    <div className="hidden md:flex h-screen w-64 flex-col fixed left-0 top-0 border-r border-slate-700 bg-slate-900 z-50">
      <div className="p-6">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">
          SkillTrack
        </h1>
      </div>
      
      <nav className="flex-1 px-4 space-y-2">
        <button
          onClick={() => setView('dashboard')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
            currentView === 'dashboard' 
              ? 'bg-indigo-600 text-white' 
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <LayoutDashboard size={20} />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setView('courses')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
            currentView === 'courses' 
              ? 'bg-indigo-600 text-white' 
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <BookOpen size={20} />
          <span>All Courses</span>
        </button>
      </nav>

      <div className="p-4 border-t border-slate-700">
        <button
          onClick={onAddCourse}
          className="w-full flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-lg transition-all transform active:scale-95"
        >
          <PlusCircle size={20} />
          <span>Add New Course</span>
        </button>
      </div>
    </div>
  );
};