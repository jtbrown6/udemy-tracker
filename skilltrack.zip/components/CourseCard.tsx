import React from 'react';
import { Course, CourseStatus } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './ui/Card';
import { Star, Clock, Calendar, CheckCircle2, MoreVertical, ExternalLink } from 'lucide-react';
import { calculateDaysRemaining } from '../utils';

interface CourseCardProps {
  course: Course;
  onEdit: (course: Course) => void;
  onToggleFavorite: (id: string) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course, onEdit, onToggleFavorite }) => {
  const daysRemaining = calculateDaysRemaining(course.deadline);
  
  const statusColors = {
    [CourseStatus.COMPLETED]: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    [CourseStatus.IN_PROGRESS]: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    [CourseStatus.UP_NEXT]: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    [CourseStatus.PENDING]: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };

  return (
    <Card className="group relative flex flex-col h-full hover:border-indigo-500/50">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start gap-4">
          <div className="space-y-1">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              {course.category}
            </span>
            <CardTitle className="text-base line-clamp-2 leading-tight group-hover:text-indigo-400 transition-colors">
              {course.title}
            </CardTitle>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); onToggleFavorite(course.id); }}
            className={`p-1.5 rounded-full transition-colors ${
              course.isFavorite ? 'text-yellow-400 bg-yellow-400/10' : 'text-slate-600 hover:bg-slate-700'
            }`}
          >
            <Star size={18} fill={course.isFavorite ? "currentColor" : "none"} />
          </button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 space-y-4">
        {/* Progress Section */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Progress</span>
            <span>{course.completionRatio}%</span>
          </div>
          <div className="h-2 w-full bg-slate-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-500 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${course.completionRatio}%` }}
            />
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
           <div className={`col-span-2 flex items-center gap-2 px-2 py-1 rounded border ${statusColors[course.status]}`}>
             <CheckCircle2 size={14} />
             <span className="font-medium">{course.status}</span>
           </div>
           
           {course.deadline && (
             <div className={`col-span-2 flex items-center gap-2 px-2 py-1 rounded border ${
               daysRemaining !== null && daysRemaining < 0 ? 'bg-red-900/20 border-red-800 text-red-400' : 'bg-slate-700/50 border-slate-700'
             }`}>
               <Clock size={14} />
               <span>
                 {daysRemaining !== null 
                   ? (daysRemaining < 0 ? `${Math.abs(daysRemaining)} days overdue` : `${daysRemaining} days left`) 
                   : 'No deadline'}
               </span>
             </div>
           )}
        </div>
        
        {course.notes && (
             <div className="flex items-center gap-2 text-xs text-indigo-400 mt-2">
                <ExternalLink size={12} />
                <span className="truncate max-w-[200px]">{course.notes}</span>
             </div>
        )}
      </CardContent>

      <CardFooter className="border-t border-slate-700/50 mt-auto">
        <div className="flex justify-between items-center w-full text-xs text-slate-500">
            <div className="flex items-center gap-1">
                <Calendar size={14} />
                <span>{course.date}</span>
            </div>
            <button 
                onClick={() => onEdit(course)}
                className="hover:text-white transition-colors px-2 py-1 hover:bg-slate-700 rounded"
            >
                Manage
            </button>
        </div>
      </CardFooter>
    </Card>
  );
};