import React from 'react';
import { Course, CourseStatus } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { Trophy, Clock, BookOpen, AlertCircle } from 'lucide-react';

interface DashboardProps {
  courses: Course[];
}

export const Dashboard: React.FC<DashboardProps> = ({ courses }) => {
  // Stats Calculation
  const total = courses.length;
  const completed = courses.filter(c => c.status === CourseStatus.COMPLETED).length;
  const inProgress = courses.filter(c => c.status === CourseStatus.IN_PROGRESS).length;
  const pending = courses.filter(c => c.status === CourseStatus.PENDING).length;
  const upNext = courses.filter(c => c.status === CourseStatus.UP_NEXT).length;
  
  // Category Data for Chart
  const categoryCounts: {[key: string]: number} = {};
  courses.forEach(c => {
      categoryCounts[c.category] = (categoryCounts[c.category] || 0) + 1;
  });
  const categoryData = Object.entries(categoryCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8); // Top 8 categories

  // Status Data for Pie Chart
  const statusData = [
    { name: 'Completed', value: completed, color: '#10b981' }, // emerald-500
    { name: 'In Progress', value: inProgress, color: '#6366f1' }, // indigo-500
    { name: 'Pending', value: pending + upNext, color: '#64748b' }, // slate-500
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-indigo-500/30 bg-gradient-to-br from-slate-800 to-indigo-900/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">Total Courses</CardTitle>
                <BookOpen size={18} className="text-indigo-400" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{total}</div>
            </CardContent>
        </Card>
        
        <Card className="border-emerald-500/30 bg-gradient-to-br from-slate-800 to-emerald-900/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">Completed</CardTitle>
                <Trophy size={18} className="text-emerald-400" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{completed}</div>
                <p className="text-xs text-emerald-400/80 mt-1">{Math.round((completed/total)*100)}% Completion Rate</p>
            </CardContent>
        </Card>

        <Card className="border-amber-500/30 bg-gradient-to-br from-slate-800 to-amber-900/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">In Progress</CardTitle>
                <Clock size={18} className="text-amber-400" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{inProgress}</div>
                <p className="text-xs text-amber-400/80 mt-1">Active Learning</p>
            </CardContent>
        </Card>

        <Card className="border-rose-500/30 bg-gradient-to-br from-slate-800 to-rose-900/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">Backlog</CardTitle>
                <AlertCircle size={18} className="text-rose-400" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{pending}</div>
                <p className="text-xs text-rose-400/80 mt-1">Ready to start</p>
            </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="h-[400px]">
            <CardHeader>
                <CardTitle>Course Distribution by Category</CardTitle>
            </CardHeader>
            <CardContent className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={categoryData} layout="vertical" margin={{ left: 20 }}>
                        <XAxis type="number" stroke="#64748b" />
                        <YAxis dataKey="name" type="category" width={100} stroke="#94a3b8" fontSize={12} tickLine={false}/>
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                            itemStyle={{ color: '#e2e8f0' }}
                        />
                        <Bar dataKey="count" fill="#6366f1" radius={[0, 4, 4, 0]}>
                            {categoryData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={['#6366f1', '#8b5cf6', '#a855f7', '#d946ef'][index % 4] || '#6366f1'} />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>

        <Card className="h-[400px]">
            <CardHeader>
                <CardTitle>Completion Status</CardTitle>
            </CardHeader>
            <CardContent className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={statusData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {statusData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                            ))}
                        </Pie>
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                            itemStyle={{ color: '#e2e8f0' }}
                        />
                    </PieChart>
                </ResponsiveContainer>
                <div className="flex justify-center gap-4 mt-4 text-xs text-slate-400">
                    {statusData.map(d => (
                        <div key={d.name} className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }}></div>
                            <span>{d.name} ({d.value})</span>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
};